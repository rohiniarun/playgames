![Heal'em All. Promo.](https://dl.dropboxusercontent.com/u/8751332/promo.png)

## Heal'em All. There's a cure for zombies.

Imagine, what if the cure exists? What if zombies plague can be stoped?
Explore old, abandoned graveyard, heal as many zombies as you can, and find your way out.
But be careful not to become one of them!

We present you our first HTML5 game. Play it anywhere and anyhow you want.
We also support latest mobile devices!

## How we use game jam "change" theme?

In our game zombies plague can be stoped, so you don't kill them, but heal them and "change" back to humans.
Turned humans need to be protected, as they can "change" back to zombies after being beaten.

Our protagonist also doesn't die, but "changes" to zombie. You have even oportunity to play him in zombie form.

## Team

-   [Kris Urbas](https://twitter.com/krzysu) - programming, story
- 	[Pawel Madeja](https://twitter.com/pawelmadeja) - graphics

![Heal'em All. Promo.](https://dl.dropboxusercontent.com/u/8751332/promo2.png)

## Open source

Great thanks to authors of these projects!

-   [Quintus JavaScript game engine](http://html5quintus.com/)
-   [grunt.js](http://gruntjs.com/)

Audio downloaded from [OpenGameArt](http://opengameart.org/)

## Copyright

This game is open source, but that doesn't mean you can just copy it and use it as your own.
You can reuse some code parts, take a look how we solved some problems etc.

**It is forbiden to use this game for profit.**

All rights reserved for graphic design. You are not allowed to use graphic from this game in your own projects.

Copyright (c) 2013 Krzysztof Urbas (@krzysu) and Paweł Madeja (@pawelmadeja).